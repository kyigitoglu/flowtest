# Changelog

## [1.2.0](https://github.com/signifly/release-please-demo/compare/v1.1.0...v1.2.0) (2025-07-01)


### Features

* Update README.md ([#9](https://github.com/signifly/release-please-demo/issues/9)) ([3cee5b4](https://github.com/signifly/release-please-demo/commit/3cee5b4a93a5a44774671506f93740550e5bff2d))


### Bug Fixes

* Update README.md ([#7](https://github.com/signifly/release-please-demo/issues/7)) ([8850fcc](https://github.com/signifly/release-please-demo/commit/8850fcc4efe6923109d1b824bb8bbc2e1191b459))

## [1.1.0](https://github.com/signifly/release-please-demo/compare/v1.0.0...v1.1.0) (2025-07-01)


### Features

* 2 ([#6](https://github.com/signifly/release-please-demo/issues/6)) ([2ef3f88](https://github.com/signifly/release-please-demo/commit/2ef3f889eb3380b0e563c62ac2e33ee0b1a99445))
* test feat 1 ([#4](https://github.com/signifly/release-please-demo/issues/4)) ([9389738](https://github.com/signifly/release-please-demo/commit/9389738425026238fd83c8b20fb6484a061b6329))

## 1.0.0 (2025-07-01)


### Features

* Update README.md to include new section with additional text ([1cef7b5](https://github.com/signifly/release-please-demo/commit/1cef7b51e65e8b819839bed6a3e9c09b604df7d2))
